# PersonalAI.cloud — Astro SEO Site

A fast, static, SEO-first Astro build for the 250-page topical authority
structure. This delivers the homepage, every reusable hub template, and a
data-driven route that already generates all 250 pages from `src/data/sitemap.json`.

## Design system ("the recall thread")

The signature idea: PersonalAI.cloud's whole differentiator is *memory that
survives time* — so the one visual motif used throughout is a dashed gold
"thread" that stitches together dated moments (a chat message, a FAQ answer, a
setup step), instead of generic numbered circles or icon grids.

- **Colors** — `ink` (#0B0E11, near-black surface), `paper` (#ECE7DD, warm
  off-white text), `thread` (#E8A33D, the signature gold accent — used
  sparingly), `whatsapp` (#25D366, reserved only for WhatsApp-specific chips),
  `ash` (muted secondary text/borders), `coral` (sparing highlight).
- **Type** — Fraunces (display/headlines, characterful serif), Inter (body/UI),
  IBM Plex Mono (timestamps and data — reinforcing the "memory" theme literally
  in the typography).
- **Signature layout element** — the hero's stitched timeline of dated chat
  snippets (`src/pages/index.astro`), reused in miniature as the `thread-rail`
  utility class for FAQ lists and setup steps.

All tokens live in `tailwind.config.mjs`; global type/utility classes are in
`src/styles/global.css`.

## Structure

```
src/
├── data/
│   ├── sitemap.json       # All 250 pages: url, hub, title, meta, + hub-specific fields
│   ├── languages.json     # Language cluster data (Malayalam, Hindi, Tamil, Telugu, Kannada)
│   ├── competitors.json   # Comparison page data (ChatGPT, Meta AI, Gemini, etc.)
│   └── roles.json         # Use-case page data (pain points + solutions per role)
├── components/
│   ├── SEO.astro          # title/description/canonical/OG/twitter/JSON-LD
│   ├── Header.astro / Footer.astro / Breadcrumbs.astro / CTA.astro
│   ├── RelatedLinks.astro / FaqBlock.astro (emits FAQPage schema)
│   └── templates/         # One component per hub type (see below)
├── layouts/
│   └── BaseLayout.astro   # Wraps every page; injects Organization + WebSite JSON-LD
└── pages/
    ├── index.astro        # Homepage (hand-built, full hero/sections)
    ├── [...slug].astro    # Generates the other 249 pages from sitemap.json
    └── sitemap.xml.ts      # Auto-generated from the same data
```

## Hub → template mapping

| Hub | Template | Notes |
|---|---|---|
| `core`, `advanced`, `growth`, `final` | `Core.astro` | General informational pages |
| `build` | `Build.astro` | Setup/how-to pages, timestamped steps |
| `whatsapp`, `whatsapp_feat` | `Whatsapp.astro` | Includes the chat-thread demo |
| `android` | `Android.astro` | Permission/integration grid |
| `free` | `Free.astro` | Included/not-included plan comparison |
| `comparison` | `Comparison.astro` | Looks up `competitors.json` by `page.competitor` |
| `usecase` | `Usecase.astro` | Looks up `roles.json` by `page.role` |
| `integration` | `Integration.astro` | Looks up `page.tool` |
| `faq` | `Faq.astro` | Three FAQPage-schema blocks |
| `language` | `Language.astro` | Looks up `languages.json` by `page.lang` |

## Scaling past 250 pages

To add more pages, just append entries to `src/data/sitemap.json` (and, if
needed, `competitors.json` / `roles.json` / `languages.json`). No new files or
routes are required — `[...slug].astro` picks up every entry automatically via
`getStaticPaths()`, and `sitemap.xml.ts` regenerates from the same source.

## Run it

```bash
npm install
npm run dev       # http://localhost:4321
npm run build     # static output in dist/
npm run preview
```

## SEO checklist covered

- Unique title/description/canonical per page (`SEO.astro`)
- OG + Twitter card tags
- JSON-LD: `Organization` + `WebSite` (site-wide), `WebPage` (every page),
  `BreadcrumbList` (every page), `FAQPage` (FAQ blocks)
- `sitemap.xml` and `robots.txt`
- Semantic heading hierarchy (single `h1`, `h2`/`h3` beneath)
- Internal linking: every template includes a "Related pages" block plus
  in-body contextual links
- Keyboard-visible focus states and `prefers-reduced-motion` support in
  `global.css`

## Known gaps / next steps

- Real product screenshots/OG image (`/og-image.png` is referenced but not
  generated here).
- Hero copy and a few template sections are illustrative — swap in real
  screenshots, testimonials, and case studies as they become available.
- No blog/article template yet — add one under `components/templates/` and a
  matching `hub` value if long-form content is needed later.
