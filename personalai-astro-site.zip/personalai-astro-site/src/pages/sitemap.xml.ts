import type { APIRoute } from 'astro';
import sitemap from '@/data/sitemap.json';

const SITE = 'https://personalai.cloud';

export const GET: APIRoute = () => {
  const urls = sitemap
    .map(
      (page) => `  <url>
    <loc>${SITE}${page.url}</loc>
    <changefreq>weekly</changefreq>
    <priority>${page.slug === 'index' ? '1.0' : '0.7'}</priority>
  </url>`,
    )
    .join('\n');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>`;

  return new Response(xml, {
    headers: { 'Content-Type': 'application/xml' },
  });
};
