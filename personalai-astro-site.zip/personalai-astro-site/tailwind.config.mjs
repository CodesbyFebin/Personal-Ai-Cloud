/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,md,mdx}'],
  theme: {
    extend: {
      colors: {
        // ---- Design tokens ----
        // ink: the base surface — a cool near-black, not pure #000
        ink: {
          DEFAULT: '#0B0E11',
          raised: '#12161B',
          line: '#1E242B',
        },
        // paper: warm off-white body/heading text on ink
        paper: {
          DEFAULT: '#ECE7DD',
          dim: '#B9B4A9',
        },
        // thread: the signature "memory thread" gold — used sparingly,
        // for the one continuous motif that runs through the page
        thread: {
          DEFAULT: '#E8A33D',
          soft: '#F4C878',
          dim: '#8A6A2E',
        },
        // whatsapp: real brand green, reserved ONLY for WhatsApp-specific
        // chips/icons/CTAs so it reads as an integration mark, not a theme color
        whatsapp: '#25D366',
        // ash: muted secondary text and hairline borders
        ash: {
          DEFAULT: '#8B93A0',
          faint: '#4A515C',
        },
        // coral: sparing use for "where we differ" / alerts
        coral: '#FF6B57',
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        body: ['"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      backgroundImage: {
        'thread-line':
          'repeating-linear-gradient(to bottom, transparent, transparent 6px, rgba(232,163,61,0.55) 6px, rgba(232,163,61,0.55) 10px)',
      },
    },
  },
  plugins: [],
};
